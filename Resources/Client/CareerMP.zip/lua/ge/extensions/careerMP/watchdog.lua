local M = {}

local logTag = "careerMP.watchdog"
local features = {}
local retryDelay = 5
local elapsed = 0
local summaryPrinted = false

local function nowState(name)
  features[name] = features[name] or {
    name = name,
    attempts = 0,
    state = "pending",
    lastError = nil,
    path = name
  }
  return features[name]
end

local function extensionName(path)
  return (path or ""):gsub("[^%w_]", "_")
end

local function isLoaded(path)
  if type(extensions) ~= "table" then return false end
  return extensions[extensionName(path)] ~= nil
end

local function doLoad(path)
  local state = nowState(path)
  state.attempts = state.attempts + 1

  local ok, err = xpcall(function()
    load(path)
    setExtensionUnloadMode(path, "manual")
  end, debug.traceback)

  if ok and isLoaded(path) then
    state.state = state.attempts > 1 and "recovered" or "loaded"
    state.lastError = nil
    log("I", logTag, string.format("%s: %s on attempt %d", state.state, path, state.attempts))
    return true
  end

  state.state = state.attempts > 1 and "failed-final" or "failed-retry-pending"
  state.lastError = tostring(err or "extension not present after load()")
  log("E", logTag, string.format(
    "%s: %s attempt %d failed: %s",
    state.state, path, state.attempts, state.lastError
  ))
  return false
end

function M.loadPersistent(path)
  return doLoad(path)
end

function M.recordFailure(name, err)
  local state = nowState(name)
  state.state = "runtime-failed"
  state.lastError = tostring(err)
  log("E", logTag, "runtime failure: " .. tostring(name) .. ": " .. tostring(err))
end

function M.recordSuccess(name)
  local state = nowState(name)
  if state.state ~= "recovered" then
    state.state = "loaded"
  end
  state.lastError = nil
end

local function retryPending()
  for path, state in pairs(features) do
    if state.state == "failed-retry-pending" and state.attempts < 2 then
      log("W", logTag, "retrying failed CareerMP feature once: " .. tostring(path))
      doLoad(path)
    end
  end
end

local function stateCounts()
  local counts = {
    loaded = 0,
    recovered = 0,
    pending = 0,
    failed = 0,
    runtimeFailed = 0
  }
  for _, state in pairs(features) do
    if state.state == "loaded" then
      counts.loaded = counts.loaded + 1
    elseif state.state == "recovered" then
      counts.recovered = counts.recovered + 1
    elseif state.state == "failed-retry-pending" or state.state == "pending" then
      counts.pending = counts.pending + 1
    elseif state.state == "runtime-failed" then
      counts.runtimeFailed = counts.runtimeFailed + 1
    else
      counts.failed = counts.failed + 1
    end
  end
  return counts
end

function M.retryPending()
  retryPending()
end

function M.dumpSummary()
  local counts = stateCounts()
  log("I", logTag, "========== CareerMP feature health ==========")
  log("I", logTag, string.format(
    "loaded=%d recovered=%d pending=%d failed=%d runtimeFailed=%d",
    counts.loaded, counts.recovered, counts.pending, counts.failed, counts.runtimeFailed
  ))

  local names = {}
  for name in pairs(features) do table.insert(names, name) end
  table.sort(names)

  summaryPrinted = true

  for _, name in ipairs(names) do
    local state = features[name]
    local line = string.format("[%s] %s (attempts=%d)", state.state, name, state.attempts)
    if state.lastError then
      line = line .. " :: " .. state.lastError:gsub("[\r\n]+", " | ")
    end
    local level = (state.state == "loaded" or state.state == "recovered") and "I" or "W"
    log(level, logTag, line)
  end
  log("I", logTag, "============================================")
  return features
end

function M.getFeatureHealth()
  return features
end

function M.onUpdate(dtReal)
  elapsed = elapsed + (dtReal or 0)

  if elapsed >= retryDelay then
    retryPending()
  end

  if elapsed >= retryDelay + 2 and not summaryPrinted then
    M.dumpSummary()
  end
end

function M.onCareerActive(active)
  if active then
    retryPending()
    M.dumpSummary()
  end
end

function M.onExtensionLoaded()
  log("I", logTag, "CareerMP watchdog active; failed feature loads will continue and retry once")
end

return M
